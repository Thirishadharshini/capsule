#ifndef GLUEDETECTION
#define GLUEDETECTION

#include "signedConvolution.hpp"
#include "changeBrightness.hpp"
#include "roiAreaScore.hpp"

#endif
