#ifndef CONVOLUTIONBALUNS
#define CONVOLUTIONBALUNS

#include <opencv2/opencv.hpp>
#include <stdexcept>
using namespace cv;

namespace signedConvolution
{
    void signedConvolution(Mat src, Mat &dst);
} // namespace signedConvolution



#endif 
